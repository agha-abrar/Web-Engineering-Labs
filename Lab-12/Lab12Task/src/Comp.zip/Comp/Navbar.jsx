import React from 'react';
import '../Comp/Navbar.css'
function Navbar() {
  return (
    <div className='nav'>
        Navbar
    </div>
  );
}

export default Navbar;