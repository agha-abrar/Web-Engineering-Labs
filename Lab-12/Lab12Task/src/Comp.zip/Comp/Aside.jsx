import React from 'react';
import '../Comp/Aside.css'
function Aside() {
  return (
    <div  className='aside'>
            Aside
    </div>
  );
}

export default Aside;
    