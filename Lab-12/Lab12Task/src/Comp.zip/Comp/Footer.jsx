import React from 'react';
import '../Comp/Navbar.css'
function Footer() {
  return (
    <div className='nav'>
        Navbar
    </div>
  );
}

export default Footer;
